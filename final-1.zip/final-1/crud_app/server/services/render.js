const axios = require('axios');

exports.homeRoutes = (req, res) => {
    // Make a get request to /api/users
    axios.get('http://localhost:3000/api/books')
    .then(function(response){
 console.log(response.data)
        res.render('index', { boooks : response.data });
    })
    .catch(err =>{
        res.send(err);
    })

    res.render('index',{books:"New Data"});
}

exports.add_book = (req, res) =>{
    res.render('add_book');
}

exports.update_book = (req, res) =>{
    axios.get('http://localhost:3000/api/books', { params : { id : req.query.id }})
        .then(function(bookdata){
            res.render("update_user", { book : bookdata.data})
        })
        .catch(err =>{
          res.send(err);
        })
}