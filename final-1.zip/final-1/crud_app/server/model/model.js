const mongoose = require('mongoose');
var Schema = new mongoose.Schema({
     title : {
        type : String,
        required: true
    },
     author : {
     type: String,
        required: true,
        unique: true
    },
    summary :{
        type : String,
        required: true
    },
    isbn :{
        type : Number,
        required: true
    }
    

})

const Userdb = mongoose.model('bookdb', Schema);

module.exports = Userdb;