const express = require('express');
const route = express.Router()
route.use(express.json());
const services=require('../services/render');
const controller=require('../controller/controller');


/**
 *  @description Root Route
 *  @method GET /
 */

route.get('/',services.homeRoutes);
/**
 *  @description add book
 *  @method GET /add-user
 */


route.get('/add-book',services.add_book)
/**
 *  @description update book
 *  @method GET /update-user
 */

route.get('/update-book', services.update_book)


//api
route.post('/api/books',controller.create);
//route.get('/api/books',controller.find);
//route.put('/api/books/:id',controller.update);
//route.delete('/api/books/:id',controller.delete);

module.exports = route